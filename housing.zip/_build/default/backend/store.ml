open Yojson
open Yojson.Basic
open Yojson.Basic.Util
open Post

let post_data = "./post_data.json"

let post_data_json = from_file post_data

let student_comments = "./comments_students_data.json"

let student_comments_json = from_file student_comments

let all_comments = "./comments_all_data.json"

let all_comments_json = from_file all_comments

(** let default json str = if postboard_from_json json = empty then
    `String str else json *)
let default json str = json

let j = ref (default post_data_json "no posts")

let c_students =
  ref (default student_comments_json "no student comments")

let c_all = ref (default all_comments_json "no public comments")

let combine_json t r file =
  let temp () =
    match !r with
    | `String _ -> t
    | _ -> combine !r t
  in
  r := temp ();
  to_file file !r

let store_post
    (post_id : string)
    (username : string)
    (user_id : string)
    (location : string)
    (bedrooms : int)
    (price : float)
    (post_info : string) =
  let jsn =
    `Assoc
      [
        ( post_id,
          `Assoc
            [
              ("post_id", `String post_id);
              ( "user",
                `Assoc
                  [
                    ("username", `String username);
                    ("user_id", `String user_id);
                    ("user_type", `String "landlord");
                  ] );
              ("location", `String location);
              ("bedrooms", `Int bedrooms);
              ("price", `Float price);
              ("post_info", `String post_info);
            ] );
      ]
  in
  combine_json jsn j post_data

let comment_jsn username post_id position comment_info =
  `Assoc
    [
      ( string_of_int position ^ post_id,
        `Assoc
          [
            ("username", `String username);
            ("post_id", `String post_id);
            ("position", `Int position);
            ("info", `String comment_info);
          ] );
    ]

let store_student_comment username post_id position comment_info =
  let jsn = comment_jsn username post_id position comment_info in
  combine_json jsn c_students student_comments

let store_public_comment username post_id position comment_info =
  let jsn = comment_jsn username post_id position comment_info in
  combine_json jsn c_all all_comments
