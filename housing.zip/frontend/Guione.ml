
open Search
open Comment
open Post

let search_results = 
  let post_data = Yojson.Basic.from_file "./post_data.json" in 
  let post_data_postboard = postboard_from_json post_data in 
  let c_students_data = Yojson.Basic.from_file "./comments_students_data.json" 
in let c_students_data_list = comments_from_json c_students_data in 
let c_all_data = Yojson.Basic.from_file "./comments_all_data.json" in 
let c_all_data_list = comments_from_json c_all_data in 
    let id_list = post_ids post_data_postboard in
    posts_to_string post_data_postboard c_students_data_list c_all_data_list
    (id_list)

(*Initializes GLib*)
let locale = GMain.init()

(*y[home_posts] are all posts that are shown in the home screen*)
let home_posts = search_results 

(*[login_window] is a GWindow and the only thing showing when the application 
is launched. It has a login feature and a button to create a new account.*)
let login_window = GWindow.window () 
let _ = login_window#resize ~width: 600 ~height: 800;
login_window#show ();
login_window#set_title "Cornell Housing Login" 

(*[signup_window] is a GWindow. It allows a user to make a new account.*)
let signup_window = GWindow.window ()
let _ = signup_window#resize ~width: 400 ~height: 400;
signup_window#set_title "Cornell Housing Sign up"

(*[window] is GWindow where the main features of the application are. It has 
a home screen, a search screen, and a profile screen.*)
let window = GWindow.window ()
let _ = window#resize ~width: 600 ~height: 800;
window#set_title "Cornell Housing Finder"

(*[main_table] is a table with 2 rows and 1 column packed inside the login_window.
It stores the login_table and button_table inside it.*)
let main_table = GPack.table ~rows: 2 ~columns:1 ~packing: login_window#add ()

(*[login_table] is a table with 4 rows and 3 columns packed inside the first row 
of the main_table inside the login_window. All labels and inputs for login 
are put inside it.*)
let login_table = GPack.table
~rows:4 
~columns: 3 
~packing: (main_table#attach ~left:0 ~top: 0) () 

(*[warning_labels] is a label which warns the user when they enter an 
invalid username or password. It starts blank until this happens. *)
let warning_label = GMisc.label ~text: "" 
~packing: (login_table#attach ~left:2 ~top:3) ()


(*[user_label] is a label which reads "username" in the login window*)
let user_label = GMisc.label ~text: "Username: " 
~packing: (login_table#attach ~left: 0 ~top:0) ()

(*[user_input] is a GEdit which allows the users to enter their username while
logging in*)
let user_input = GEdit.entry ~packing:(login_table#attach ~left: 1 ~top: 0)() 

(*[pass_label] is a label which reads "password" in the login window*)
let pass_label = GMisc.label 
  ~text: "Password: " ~packing:(login_table#attach ~left: 0 ~top: 1)() 

  (*[pass_input] is a GEdit which allows the users to enter their password while
logging in*)
let pass_input = GEdit.entry ~packing:(login_table#attach ~left: 1 ~top: 1)() 

(*[login_callback] is the functionality for when the login button is pushed *)
let login_callback () = if user_input#text = "" || pass_input#text = "" 
  then warning_label#set_text "Username and password may not be empty" else 
  if 1 == 1 then (window#show(); login_window#destroy ()) 
  else warning_label#set_text "Invalid username or password"

(*[button_table] is a table with 2 rows and 1 column packed inside the main_table 
inside the login_window. It stores the signupwindow_button and the login_button
inside it.*)
let button_table = GPack.table
~rows: 2
~columns:1
~packing: (main_table#attach ~left: 0 ~top:1) ()

(*[login_button] is a button in the login_window that calls the login_callback
when clicked.*)
let login_button = GButton.button
  ~label: "Login"
  ~packing: (button_table#attach ~left:1 ~top: 0) ()
  let _ = login_button#connect#clicked 
  ~callback: (login_callback) 

  (*[signupwindow_callback] opens up the signup window. *)
 let signupwindow_callback () = 
  signup_window#show ();
  login_window#destroy ()

(*[signupwindow_button] is a button in the login_window that calls the 
signupwindow_callback when clicked.*)
  let signupwindow_button = GButton.button
  ~label: "Sign up"
  ~packing: (button_table#attach ~left: 0 ~top: 0) () 

  let _ = signupwindow_button#connect#clicked
  ~callback: (signupwindow_callback)

(*[login_table] is a table with 3 rows and 3 columns inside the signup_window. 
All labels, inputs, and buttons for signing up are put inside it.*)
  let signup_table = GPack.table 
  ~rows: 3
  ~columns: 3
  ~packing: signup_window#add ()

(*[userlandlord_button] is a radio button attached to the signup_table in the 
signup_window. When selected the usertype of the account will be landlord.*)
let userlandlord_button = GButton.radio_button
  ~label: "Landlord" ~packing:(signup_table#attach ~left:0 ~top: 0) ()
 
(*[userstudent_button] is a radio button attached to the signup_table in the 
signup_window. It's grouped with the other user type so that only one can be selected. 
When selected the usertype of the account will be student.*)
let userstudent_button = GButton.radio_button
  ~group:userlandlord_button#group
  ~label: "Student" ~packing:(signup_table#attach ~left:1 ~top: 0)()

(*[newusername_label] is a label that reads Username inside the signup_table in 
the signup_window.*)
let newusername_label = GMisc.label
~text: "Username: " ~packing: (signup_table#attach ~left: 0 ~top:1) ()

(*[newuser_input] is a GEdit entry which allows the users to enter their new 
username while signing up.*)
let newuser_input = GEdit.entry 
~packing:(signup_table#attach ~left: 1 ~top: 1) ()

(*[newpass_label] is a label that reads Password inside the signup_table in 
the signup_window.*)
let newpass_label = GMisc.label
~text: "Password: " 
~packing: (signup_table#attach ~left: 0 ~top: 2) ()

(*[newpass_input] is a GEdit entry which allows the users to enter their new 
password while signing up.*)
let newpass_input = GEdit.entry 
~packing: (signup_table#attach ~left: 1 ~top: 2) ()


(*[signupwarning_label] is a label that shows up when the user inputs a new username 
that already exists and clicks the signup_button. It's inside the signup_table.*)
let signupwarning_label = GMisc.label ~text: "" 
  ~packing: (signup_table#attach ~left:2 ~top:2) ()
let signup_callback () = 
if newuser_input#text = "" || newpass_input#text = "" 
  then signupwarning_label#set_text 
  "Username and password may not be empty" else if 1==1 then
(window#show (); signup_window#destroy ()) else signupwarning_label#set_text 
"Username already exists"

(*[signup_button] is a button inside the signup_table that takes the user to the 
main page if their inputs are valid or shows the signupwarning_label to
indicate that the user needs to change something.*)
let signup_button = GButton.button
  ~label: "Sign up" ~packing: (signup_table#attach ~left: 2 ~top:3) ()
  
let _ = signup_button#connect#clicked
~callback: (signup_callback)


 (*[table_of_tables] is a table with 2 rows and 1 columns inside the main window. 
Multiple other tables are put inside it.*)
 let table_of_tables = GPack.table
 ~rows: 2
 ~columns: 1
 ~packing:window#add  () 

(*[menu_table] is a table with 1 row and 4 columns packed inside the main window. 
It stores 4 buttons: profile, quit, search, and home.*) 
  let menu_table = GPack.table 
  ~rows: 1
  ~columns: 4
  ~packing:(table_of_tables#attach ~left: 0 ~top: 0 ~expand: `X) ()

  (*[quit_button] is a button inside the menu_table. When clicked it quits the GUI.*)
  let quit_button = GButton.button
  ~label: "X"
  ~packing: (menu_table#attach ~left:3 ~top:0) ()

  let _ = quit_button#connect#clicked
  ~callback: (fun () -> GMain.quit())

  let profile_table = GPack.table 
  ~rows: 3
  ~columns: 4
  ~packing: (table_of_tables#attach ~left:0 ~top: 1 ~expand: `X)
  ~show: true ()

  (*[name_label] is a label which displays information.*)
  let name_label = GMisc.label
  ~text: home_posts
  ~packing: (profile_table#attach ~left: 3 ~top: 2)()

(*[home_button] is a button inside the menu_table. When clicked it changes the display
to home (where posts are).*)
  let home_button = GButton.button 
      ~label:"HOME" ~packing: (menu_table#attach ~left:0 ~top: 0 ~expand: `X) ()
       
  let _ = home_button#connect#clicked 
  ~callback:(fun () -> name_label#set_text home_posts)

(*[search_button] is a button inside the menu_table. When clicked it changes the display
to search where users can select filters to look for houses.*)
  let search_button = GButton.button 
      ~label:"SEARCH"
      ~packing: (menu_table#attach ~left:1 ~top: 0 ~expand: `X) ()
       
  let _ = search_button#connect#clicked 
  ~callback:(fun _ -> print_endline "")

(*[profile_button] is a GButton. When pressed, it displays information about 
the user. *)
let profile_button = GButton.button 
      ~label:"PROFILE"
      ~packing: (menu_table#attach ~left:2 ~top: 0 ~expand: `X) 
     () 

  let _ = profile_button#connect#clicked 
  ~callback: (fun () -> name_label#set_text "Name: Yekta \n Type: Owl")

(*Starts the main GUI loop*)
let main() = 
GMain.Main.main ()

let _ = main ()